import sys

LG=sys.argv[1]
out1 = open("markers."+LG+".v2.txt","w")

#inZ = open("ch"+LG+".BB.Lepmap.txt","rU")
inZ = open("LG.initial.txt","rU")
v1s=[]
orientations=[]
for line_idx, line in enumerate(inZ):
# 13	410	pos
	cols = line.replace('\n', '').split('\t') 
	if cols[0]==LG:
		v1s.append(cols[1])
		orientations.append(cols[2])
totscaffs=len(v1s)

v1marks={}
iny = open("g.F2.113.txt","rU") # all markers in this mapping pop
for line_idx, line in enumerate(iny):
	cols = line.replace('\n', '').split('\t') 	
# imswc700	1	0	NN
	try:
		v1marks[cols[1]].append(cols[2])
	except KeyError:
		v1marks[cols[1]]=[cols[2]]

for j in range(totscaffs):
	chosenv1=v1s[j]
	try:
		zz=v1marks[v1s[j]]
		print v1s[j],v1marks[v1s[j]]
		if orientations[j]=='pos':
			for k in range(len(zz)):
				out1.write(v1s[j]+'\t'+zz[k]+'\n')
				#print v1s[j],zz[k]
		elif orientations[j]=='neg':
			for k in range(len(zz)):
				out1.write(v1s[j]+'\t'+zz[len(zz)-k-1]+'\n')		

	except KeyError:
		print v1s[j],"missing"
